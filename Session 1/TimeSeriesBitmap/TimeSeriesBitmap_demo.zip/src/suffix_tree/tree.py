# -*- coding: utf-8 -*-
#

"""
A Generalized Suffix Tree
"""

import collections
import itertools

from . import ukkonen
from . import lca_mixin
from .node import Internal
from .util import Path, UniqueEndChar, is_debug

class Tree (lca_mixin.Tree):
    """A suffix tree.

    The key feature of the suffix tree is that for any leaf :math:`i`, the
    concatenation of the edgle-labels on the path from the root to leaf
    :math:`i` exactly spells out the suffix of :math:`S` that starts at point
    :math:`i`.  That is, it spells out :math:`S[i..m]`.

    Initialize and interrogate the tree:

    >>> tree = Tree ({ 'A' : 'xabxac' })
    >>> tree.find ('abx')
    True
    >>> tree.find ('abc')
    False

    >>> tree = Tree ({ 'A' : 'xabxac', 'B' : 'awyawxacxz' })
    >>> for id_, path in tree.find_all ('xac'):
    ...    print (id_, ':', str (path))
    A : x a c $
    B : x a c x z $
    >>> tree.find_all ('abc')
    []

    >>> from . import naive
    >>> tree = Tree ({ 'A' : 'xabxac' }, naive.Builder)
    >>> tree.find ('abx')
    True
    >>> tree.find ('abc')
    False

    """

    def __init__ (self, d = None, builder = ukkonen.Builder):
        """ Initialize and build the tree from a dict of iterables.

        :param dict d: a dictionary of id: iterable
        """

        d = d or {}

        super ().__init__ (d)

        self.root = Internal (None, Path (tuple (), 0, 0), name = 'root')

        for id_, S in d.items ():
            self.add (id_, S, builder)


    def add (self, id_, S, builder = ukkonen.Builder):
        """ Add items to tree from iterable

        :param string id_: an id
        :param iterable S: an iterable of hashables

        >>> tree = Tree ()
        >>> tree.add ('A', 'xabxac')
        >>> tree.add ('B', 'awyawxawxz')
        >>> tree.find ('abx')
        True
        >>> tree.find ('awx')
        True
        >>> tree.find ('abc')
        False
        """

        # input is any iterable, make an immutable copy with a unique
        # character at the end
        path = Path.from_iterable (itertools.chain (S, [UniqueEndChar (id_)]))

        self.builder = builder (self, id_, path)

        try:
            self.builder.build ()
        except:
            if is_debug ():
                with open ('/tmp/core.dot', 'w') as tmp:
                    tmp.write (self.to_dot ())
            raise


    def find_path (self, path):
        """Find a path in the tree.

        Returns the deepest node on the path, the matched length of the path,
        and also the next deeper node if the matched length is longer than the
        string-depth of the deepest node on the path.

        """
        return self.root.find_path (path)

    def find (self, iterable):
        """ Return True if string is found

        >>> tree = Tree ({ 'A' : 'xabxac' })
        >>> tree.find ('abx')
        True
        >>> tree.find ('abc')
        False
        """

        path = Path.from_iterable (iterable)
        dummy_node, matched_len, dummy_child = self.find_path (path)
        return matched_len == len (path)


    def find_all (self, s):
        """
        ***** Modified *****
        Return the number of times a string s occurs as a substring 
        and return the offset of each match.
        """

        def leaf_finder(node, counts, offsets):
            """
            Recursive function to find all the leaves starting from a node.
            Return the number of leaves and their offset.
            """

            for key in node.children:
                child = node.children[key]

                if child.is_leaf():
                    counts += 1
                    offsets.append(str(child).split(':')[1])

                else:
                    counts, offsets = leaf_finder(child, counts, offsets)

            return counts, offsets


        path = Path.from_iterable(s)
        node, matched_len, child = self.find_path(path)

        # Node and child refer the nodes above and below an edge:
        # if the string lands on a node, then node=string and child=None

        counts = 0
        offsets = []

        # We fell off the tree: zero occurrence of the string
        if matched_len < len (path):
            return counts, offsets

        if child == None:
            # We are on an internal node
            return leaf_finder(node, counts, offsets)

        elif child.is_leaf():
            # If we are on a leaf, it is trivial
            counts += 1
            offsets.append(str(child).split(':')[1])
            return counts, offsets
            
        else:
            # We are on an edge
            return leaf_finder(child, counts, offsets)


    def find_id (self, id_, iterable):
        """ Return True if string is found with corresponding id

        :param string id_: an id
        :param iterable S: an iterable of hashables

        >>> tree = Tree ({ 'A' : 'xabxac', 'B' : 'awyawxawxz' })
        >>> tree.find_id ('A', 'abx')
        True
        >>> tree.find_id ('B', 'awx')
        True
        >>> tree.find_id ('B', 'abx')
        False
        """

        for i, p in self.find_all (iterable):
            if i == id_:
                return True
        return False

    def common_substrings (self):
        """Get a list of common substrings.

        **Definition** For each :math:`k` between 2 and :math:`K`, we define
        :math:`l(k)` to be the length of the *longest substring common to at
        least* :math:`k` *of the strings.*

        Returns a table of :math:`K - 1` entries, where entry :math:`k` gives
        :math:`l(k)`.

        >>> tree = Tree ({'A': 'sandollar', 'B': 'sandlot',
        ...    'C' : 'handler', 'D': 'grand', 'E': 'pantry'})
        >>> for k, length, path in tree.common_substrings ():
        ...    print (k, length, path)
        2 4 s a n d
        3 3 a n d
        4 3 a n d
        5 2 a n

        [Gusfield1997]_ §7.6, 127ff
        """

        self.root.compute_C ()

        V = collections.defaultdict (lambda: (0, 'no_id', None)) # C => (string_depth, id, path)
        def f (node):
            """ Helper """
            k = node.C                # no. of distinct strings in the subtree
            sd = node.string_depth ()
            if sd > V[k][0]:
                for id_, path in node.get_positions ():
                    # select an arbitrary one (the first)
                    # change the path to stop at this node
                    V[k] = (sd, id_, Path (path.S, path.start, path.start + sd))
                    break

        self.root.pre_order (f)

        l = []
        max_len = 0
        max_path = None
        for k in range (max (V.keys ()), 1, -1):
            length = V[k][0]
            if length > max_len:
                max_len = length
                max_path = V[k][2]
            l.append ((k, max_len, max_path))
        return sorted (l)

    def maximal_repeats (self):
        """Get a list of the maximal repeats in the tree.

        N.B.  The repeats must be in different input strings.

        >>> tree = Tree ({ 'A' : 'xabxac', 'B' : 'awyawxawxz' })
        >>> for C, path in sorted (tree.maximal_repeats ()):
        ...    print (C, path)
        1 a w
        1 a w x
        2 a
        2 x
        2 x a

        See [Gusfield1997]_ §7.12.1, 144ff.

        """
        self.root.compute_C ()
        self.root.compute_left_diverse ()

        a = []
        for child in self.root.children.values ():
            child.maximal_repeats (a)
        return a

    def to_dot (self):
        """ Output the tree in GraphViz .dot format. """
        dot = []
        dot.append ('strict digraph G {\n')
        self.root.to_dot (dot)
        dot.append ('}\n')
        return ''.join (dot)
