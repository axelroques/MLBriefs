# -*- coding: utf-8 -*-
#

""" Package """

from .tree import Tree, Path

__title__ = "suffix-tree"
